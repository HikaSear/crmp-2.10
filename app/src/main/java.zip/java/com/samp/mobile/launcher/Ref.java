package com.samp.mobile.launcher;

import java.util.ArrayList;

public class Ref {

    public static class ArrayListRef<T> {
        public ArrayList<T> element;
    }

    public static class IntRef {
        public int element;
    }

    public static class LongRef {
        public long element;
    }
}

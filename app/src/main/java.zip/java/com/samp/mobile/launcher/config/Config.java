package com.samp.mobile.launcher.config;

import android.app.Activity;

public class Config {

    public static Activity currentContext;
}

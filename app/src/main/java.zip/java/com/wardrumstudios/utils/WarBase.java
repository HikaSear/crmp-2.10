package com.wardrumstudios.utils;

import com.nvidia.devtech.NvEventQueueActivity;

public class WarBase extends NvEventQueueActivity {
}
